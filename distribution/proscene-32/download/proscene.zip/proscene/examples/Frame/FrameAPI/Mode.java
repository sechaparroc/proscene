public enum Mode {
  m1, m2, m3, m4, m5, m6
}